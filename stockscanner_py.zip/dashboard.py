"""
Stock Scanner Dashboard
Run with:  py -m streamlit run dashboard.py

Self-contained: pulls prices with yfinance and computes all indicators
itself, so it does not depend on scanner.py.
"""

import streamlit as st
import pandas as pd
import yfinance as yf

st.set_page_config(page_title="Stock Scanner", layout="wide", page_icon="📈")

# ---------------- Sidebar ----------------
st.sidebar.header("Watchlist")
DEFAULT_TICKERS = (
    "AAPL,MSFT,NVDA,TSLA,AMZN,GOOGL,META,AMD,NFLX,JPM,"
    "SPY,QQQ,PLTR,COIN,SOFI,DIS,BA,UBER,SHOP,INTC"
)
tickers_input = st.sidebar.text_area(
    "Tickers (comma separated)", DEFAULT_TICKERS, height=120
)
tickers = [t.strip().upper() for t in tickers_input.split(",") if t.strip()]

period = st.sidebar.selectbox("History period", ["3mo", "6mo", "1y"], index=1)
rsi_buy = st.sidebar.slider("RSI oversold level (buy)", 10, 40, 30)
rsi_short = st.sidebar.slider("RSI overbought level (short)", 60, 90, 70)

# ---------------- Indicator math ----------------
def compute_indicators(close: pd.Series) -> dict:
    delta = close.diff()
    gain = delta.clip(lower=0).rolling(14).mean()
    loss = (-delta.clip(upper=0)).rolling(14).mean()
    rs = gain / loss
    rsi = 100 - (100 / (1 + rs))

    sma20 = close.rolling(20).mean()
    sma50 = close.rolling(50).mean()
    ema12 = close.ewm(span=12, adjust=False).mean()
    ema26 = close.ewm(span=26, adjust=False).mean()
    macd = ema12 - ema26
    macd_signal = macd.ewm(span=9, adjust=False).mean()

    std20 = close.rolling(20).std()
    bb_upper = sma20 + 2 * std20
    bb_lower = sma20 - 2 * std20

    return {
        "close": close.iloc[-1],
        "chg_1d_%": (close.iloc[-1] / close.iloc[-2] - 1) * 100,
        "rsi": rsi.iloc[-1],
        "sma20": sma20.iloc[-1],
        "sma50": sma50.iloc[-1],
        "macd": macd.iloc[-1],
        "macd_signal": macd_signal.iloc[-1],
        "bb_upper": bb_upper.iloc[-1],
        "bb_lower": bb_lower.iloc[-1],
    }


def make_signal(r: dict) -> tuple[str, str]:
    """Return (signal, reasons) from simple indicator rules."""
    score, reasons = 0, []
    if r["rsi"] < rsi_buy:
        score += 2
        reasons.append(f"RSI {r['rsi']:.0f} oversold")
    elif r["rsi"] > rsi_short:
        score -= 2
        reasons.append(f"RSI {r['rsi']:.0f} overbought")

    if r["macd"] > r["macd_signal"]:
        score += 1
        reasons.append("MACD bullish")
    else:
        score -= 1
        reasons.append("MACD bearish")

    if r["sma20"] > r["sma50"]:
        score += 1
        reasons.append("Uptrend (SMA20>50)")
    else:
        score -= 1
        reasons.append("Downtrend (SMA20<50)")

    if r["close"] <= r["bb_lower"]:
        score += 1
        reasons.append("At lower Bollinger")
    elif r["close"] >= r["bb_upper"]:
        score -= 1
        reasons.append("At upper Bollinger")

    if score >= 2:
        return "🟢 BUY", " · ".join(reasons)
    if score <= -2:
        return "🔴 SHORT", " · ".join(reasons)
    return "⚪ HOLD", " · ".join(reasons)


# ---------------- Data fetch (cached 15 min) ----------------
@st.cache_data(ttl=900, show_spinner=False)
def load_data(tickers: list[str], period: str) -> pd.DataFrame:
    data = yf.download(
        tickers, period=period, interval="1d",
        progress=False, auto_adjust=True, group_by="ticker",
    )
    return data


st.title("📈 Stock Scanner")

if not tickers:
    st.info("Add at least one ticker in the sidebar.")
    st.stop()

with st.spinner(f"Scanning {len(tickers)} tickers..."):
    raw = load_data(tickers, period)

rows, failed = [], []
for t in tickers:
    try:
        close = raw[t]["Close"].dropna() if len(tickers) > 1 else raw["Close"].dropna()
        if len(close) < 60:
            failed.append(t)
            continue
        r = compute_indicators(close)
        sig, why = make_signal(r)
        rows.append({"ticker": t, "signal": sig, **r, "reasons": why})
    except Exception:
        failed.append(t)

if failed:
    st.sidebar.warning("No data for: " + ", ".join(failed))

if not rows:
    st.error("No data returned. Check your tickers or internet connection.")
    st.stop()

df = pd.DataFrame(rows)

# ---------------- Metric cards ----------------
buys = df[df["signal"].str.contains("BUY")]
shorts = df[df["signal"].str.contains("SHORT")]
c1, c2, c3, c4 = st.columns(4)
c1.metric("Scanned", len(df))
c2.metric("🟢 Buy setups", len(buys))
c3.metric("🔴 Short setups", len(shorts))
c4.metric("⚪ Holds", len(df) - len(buys) - len(shorts))

tab_all, tab_setups = st.tabs(["All tickers", "Actionable setups"])

# ---------------- Table styling ----------------
def color_signal(val):
    if "BUY" in str(val):
        return "background-color:#14532d;color:#ffffff;font-weight:bold"
    if "SHORT" in str(val):
        return "background-color:#7f1d1d;color:#ffffff;font-weight:bold"
    return "color:#9ca3af"


def color_chg(val):
    try:
        return "color:#4ade80" if val >= 0 else "color:#f87171"
    except TypeError:
        return ""


show_cols = ["ticker", "signal", "close", "chg_1d_%", "rsi",
             "sma20", "sma50", "macd", "macd_signal", "reasons"]

def styled(d: pd.DataFrame):
    return (
        d[show_cols]
        .style.map(color_signal, subset=["signal"])
        .map(color_chg, subset=["chg_1d_%"])
        .format(precision=2)
    )

with tab_all:
    st.dataframe(styled(df), use_container_width=True, height=560)

with tab_setups:
    setups = df[~df["signal"].str.contains("HOLD")]
    if setups.empty:
        st.info("No buy/short setups right now — everything is a HOLD.")
    else:
        st.dataframe(styled(setups), use_container_width=True, height=400)

# ---------------- Chart ----------------
st.divider()
pick = st.selectbox("📊 Chart a ticker", df["ticker"])
close = raw[pick]["Close"].dropna() if len(tickers) > 1 else raw["Close"].dropna()
chart_df = pd.DataFrame({
    "Close": close,
    "SMA 20": close.rolling(20).mean(),
    "SMA 50": close.rolling(50).mean(),
})
st.line_chart(chart_df, height=380)

row = df[df["ticker"] == pick].iloc[0]
st.markdown(f"**{pick}** — {row['signal']} &nbsp;|&nbsp; {row['reasons']}")

st.caption(
    "⚠️ Signals come from simple indicator rules (RSI, MACD, SMA trend, "
    "Bollinger Bands). They are screening ideas, not financial advice."
)
